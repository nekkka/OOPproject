package courses;

public enum CoursesType {
	MAJOR,MINOR,FREE_ELECTIVE;

}
