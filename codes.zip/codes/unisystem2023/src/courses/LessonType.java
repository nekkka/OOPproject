package courses;

public enum LessonType {
	PRACTICE,LECTURE;
}
