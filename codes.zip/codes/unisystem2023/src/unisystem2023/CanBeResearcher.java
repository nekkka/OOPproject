package unisystem2023;

public interface CanBeResearcher {
	public void makeResearch();
}
