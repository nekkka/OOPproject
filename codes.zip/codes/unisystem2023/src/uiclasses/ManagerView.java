package uiclasses;

import users.Manager;

public class ManagerView extends EmployeeView{

	public ManagerView(){
		super();
	}

	public ManagerView(Manager manager){
		super(manager);
	}

	public void main(){

	}

}

