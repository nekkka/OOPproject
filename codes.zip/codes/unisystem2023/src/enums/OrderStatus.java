package enums;

public enum OrderStatus {
	NEW,
	INPROGRESS,
	DONE
}
