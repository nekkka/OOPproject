package enums;

public enum OrganizationName {
	ArtHouse,
	BCL,
	OSIT,
	Crystal,
	Faces
}
