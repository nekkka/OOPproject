package enums;

public enum AcademicDegree {
	BACHELOR,
	MASTER,
	DOCTORATE
}
