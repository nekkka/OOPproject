package enums;

public enum Faculty {
	SITE,
	BS,
	ISE,
	SAM
}
