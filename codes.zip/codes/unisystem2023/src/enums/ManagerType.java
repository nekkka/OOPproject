package enums;

public enum ManagerType {
	OR,
	DEANSOFFICE
}
