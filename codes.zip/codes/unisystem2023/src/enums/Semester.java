package enums;

public enum Semester {
	FALL,SPRING,SUMMER;

}
